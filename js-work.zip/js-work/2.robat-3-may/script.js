

function robaat(client) {

    if (client == "hi"||client == "hello") {
        console.log("hi .select a languge:");
    }
    if (client == "english"||client == "persian") {
        console.log(" selected a languge");
    }
    if (client == "whats your name") {
        console.log("my name is lila")

    }
    if (client == "were are you from") {
        console.log("usa")

    }
    if (client == "how old are you") {
        console.log("2weeks")

    }
}
robaat("persian")

