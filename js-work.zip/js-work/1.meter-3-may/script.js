
// cm  to meters
function calc(data){
    let box  =data;
   console.log("cm to meter:     ",data/100);
   
  
}
calc(100)
calc(200)


//meter to 
let xarrya=[10,100,45,50]
function calcm(datam){
 let boxcm  ={};
 for(leti =1;i<=Object.keys[datam].lenght;i++)
 if(xarrya[i]==Number)
 {
  boxcm = xarrya[i]*100
 console.log("meter to cm:  " ,boxcm)
 }
}
 
calcm(xarrya)